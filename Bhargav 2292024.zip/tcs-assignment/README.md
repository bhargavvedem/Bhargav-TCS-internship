# tcs-assignment-backend
## Technolgies Used:
 Spring Boot
 
 ### Functionalities Implemented
 **1)** Added **JWT** Authentication
 
 
 **2)** Created **REST APIS** for Chart data
 
